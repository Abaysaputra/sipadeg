# SIDAPEG — pembaruan UI bergaya Modernize

Paket ini memperbarui workspace setelah login: dashboard, daftar pegawai,
form tambah/edit, detail, dan konfirmasi hapus. Dibuat untuk project React SIDAPEG
yang sudah memakai EmployeeManager, EmployeeDialog dan nomor pegawai otomatis.

Tautan Figma yang diberikan belum dapat diakses langsung saat penyusunan.
Tampilan ini merupakan adaptasi gaya dari demo publik Modernize, bukan ekspor
frame Figma atau pemasangan source template resminya. Implementasi memakai React,
CSS, dan SVG lokal sehingga tidak membutuhkan paket MUI atau dependency baru.

## 1. Lihat hasil terlebih dahulu

Ekstrak ZIP lalu klik dua kali `Preview_UI.html` untuk membukanya di Chrome/Edge.
Pratinjau dapat dipakai tanpa Laravel dan tanpa internet. Coba menu Data Pegawai,
pencarian, tambah pegawai, edit, detail dan dialog hapus.

Banner menandai bahwa semua data pratinjau adalah data fiktif. Perubahan hanya
disimpan di memori halaman, hilang setelah refresh, dan tidak terhubung ke MySQL.
File ini tidak perlu disalin ke project Anda. Source aplikasi yang dipasang tetap
memakai service API dan backend yang sebelumnya sudah berjalan.

## 2. Cadangkan komponen frontend

Lokasi project:

```text
D:\laragon\www\SIDAPEG_Setup\frontend
```

Salin folder `src\components` ke folder cadangan di luar project.
Hentikan `npm run dev` dengan Ctrl+C sebelum menyalin pembaruan.

## 3. Salin enam file

Salin semua file di `frontend/src/components` dalam paket ini ke folder
`D:\laragon\www\SIDAPEG_Setup\frontend\src\components`.
Pilih Replace untuk file yang sudah ada.

| File | Perubahan |
| --- | --- |
| Workspace.jsx | Sidebar, menu layar kecil, header dan layout utama |
| Dashboard.jsx | Kartu ringkasan dan tiga grafik berbasis data backend |
| EmployeeManager.jsx | Header direktori, avatar, badge dan tombol tindakan |
| EmployeeDialog.jsx | Form/detail/hapus dengan nomor otomatis tetap dipertahankan |
| UiIcon.jsx | Ikon SVG lokal |
| modernize.css | Warna, tipografi, spacing, kartu, tabel, dialog dan breakpoint |

File `employees.css` dari tahap sebelumnya tetap diperlukan. Biarkan file itu
di tempatnya. `Workspace.jsx` sudah mengimpor `modernize.css`, sehingga Anda tidak
perlu mengedit App.jsx, main.jsx, atau index.css.

Paket tidak berisi `api.js`, `.env`, `package.json`, `vite.config.js`, atau backend.
Gunakan versi file-file tersebut yang sudah berhasil pada project Anda.
Jika Anda pernah melakukan perubahan lain pada enam komponen di atas,
bandingkan dahulu sebelum mengganti file.

## 4. Jalankan

Terminal frontend (CMD Laragon):

```bat
cd /d D:\laragon\www\SIDAPEG_Setup\frontend
npm run dev
```

Pastikan backend tetap berjalan pada terminal terpisah:

```bat
cd /d D:\laragon\www\SIDAPEG_Setup\backend
php artisan serve
```

Buka URL yang dicetak Vite, lalu tekan Ctrl+F5. Login seperti biasa.
Tidak perlu mengimpor SQL atau mengulang setup CSRF untuk pembaruan tampilan ini.

Untuk memeriksa build pada project Anda:

```bat
npm run build
```

## 5. Perubahan yang terlihat

- Sidebar putih dengan identitas SIDAPEG, ikon, dan penanda menu aktif biru.
- Banner sambutan dengan ilustrasi sederhana dari CSS dan ikon.
- Empat kartu pastel: total pegawai, laki-laki, perempuan, dan jenjang pendidikan.
- Grafik batang pendidikan, jenis kelamin, dan kelompok usia.
- Direktori pegawai dengan avatar inisial, badge pendidikan dan tombol berikon.
- Form dengan fokus input, pesan validasi, serta nomor otomatis hanya-baca.
- Menu dapat dibuka/tutup pada layar kecil; tabel dapat digeser secara horizontal.
- Pengurangan animasi mengikuti prefers-reduced-motion.

Angka dashboard berasal dari `/api/dashboard`; tidak ada angka kenaikan bulanan
buatan. “Jenjang pendidikan” menghitung jumlah jenjang yang memiliki pegawai,
bukan jumlah pegawai atau jumlah seluruh opsi master. Panjang batang diskalakan
terhadap nilai terbesar dalam grafik yang sama. Angka dan persentase ditulis
terpisah agar informasi tidak bergantung pada warna saja.

Font memakai Plus Jakarta Sans bila sudah tersedia di halaman/perangkat, dengan
fallback Segoe UI dan Arial. Paket tidak mengunduh font dari layanan eksternal.
Tampilan login tetap mengikuti versi yang saat ini sudah terpasang.

## 6. Checklist uji di aplikasi nyata

1. Dashboard: bandingkan total dan grafik dengan data pegawai yang ada.
2. Klik Kelola pegawai dan pastikan direktori terbuka.
3. Cari berdasarkan nama/nomor dan filter divisi.
4. Tambah pegawai. Nomor muncul otomatis setelah simpan.
5. Edit nama. Nomor pegawai harus tetap.
6. Lihat detail dan batalkan dialog hapus. Data tidak berubah.
7. Hapus hanya data uji setelah menekan tombol konfirmasi.
8. Kembali ke Dashboard, lalu periksa total terbaru.
9. Kecilkan lebar browser menjadi sekitar 390 px atau gunakan Device Toolbar.
   Menu dibuka dari tombol di kanan logo, kartu tersusun dua kolom, grafik satu
   kolom, dan tabel bergeser di dalam kotaknya. Form menjadi satu kolom.
10. Uji Tab, Enter dan Escape pada dialog. Nomor pegawai harus tetap read-only.
11. Klik Keluar dan pastikan kembali ke halaman login.

## Status pemeriksaan

- Build komponen dengan Vite berhasil di lingkungan penyusunan.
- Pengujian DOM dengan API simulasi lulus: tambah, detail, ubah, pencarian,
  validasi 422, pembatalan hapus, hapus terkonfirmasi, muat ulang dashboard,
  CSRF sebelum operasi, dan penanganan sesi 401.
- Nomor otomatis tetap read-only dan tidak ikut payload POST/PUT.
- Uji tambahan lulus: dashboard kosong, proporsi batang, CTA kelola pegawai,
  error/retry, status menu terbuka/tertutup, dan callback logout.
- Pratinjau dibuat dari komponen yang sama, dengan adapter data contoh terpisah.
- Pemeriksaan visual melalui browser otomatis belum berhasil karena browser
  pemeriksaan tidak dapat mengakses server lokal. Responsivitas sudah ditulis
  dalam CSS, tetapi pemeriksaan visual akhir perlu dilakukan di browser Anda.
- Backend Laravel dan MySQL Anda tidak diakses dari lingkungan penyusunan.

## Jika tampilan belum berubah

- Pastikan enam file masuk ke folder frontend yang sedang dijalankan Vite.
- Periksa Workspace.jsx memiliki `import './modernize.css';`.
- Jika muncul “Failed to resolve import UiIcon”, pastikan nama file UiIcon.jsx
  sama persis termasuk huruf besar/kecil.
- Jika muncul error impor employees.css, pulihkan file itu dari folder cadangan.
- Tekan Ctrl+F5 setelah menjalankan ulang npm run dev.
- Bila data gagal dimuat, periksa terminal Laravel dan login kembali. Hindari
  menyalin kode data contoh dari Preview_UI.html ke service API aplikasi.

## Rujukan tampilan

- Figma yang diberikan: https://www.figma.com/file/vx7BDKIRGoSwxs5lItTMlD/Modernize
- Demo publik Modernize: https://modernize-nextjs.adminmart.com/
- Halaman template: https://mui.com/store/items/modernize-next-js-admin-template/
